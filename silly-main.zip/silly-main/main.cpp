#include <iostream>

int main() {
    std::cout << "if you've made it this far, please consider forming an eecs study group with me\n";
    return 0;
}
